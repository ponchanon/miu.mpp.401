package prob2;

public interface ClosedCurve {
	public double computePerimeter();
}
