package prob1.partE.ii;

public interface C extends A {
	 void method();

}
