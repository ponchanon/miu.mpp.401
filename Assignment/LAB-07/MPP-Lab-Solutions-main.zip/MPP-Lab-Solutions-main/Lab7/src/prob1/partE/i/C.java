package prob1.partE.i;

public interface C extends A {
	 void method();

}
