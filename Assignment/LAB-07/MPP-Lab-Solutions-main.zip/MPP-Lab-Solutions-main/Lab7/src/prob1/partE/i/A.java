package prob1.partE.i;

public interface A {
	void method();
	
}
