package prob1.partE.ii;

public interface D extends B,C  {
	

	
}
