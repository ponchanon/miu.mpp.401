package prob1.partE.i;

public class D implements B,C  {
	

	
}
