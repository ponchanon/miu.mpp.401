package prob1.partE.i;

public interface B extends A{
	  void method();
}
