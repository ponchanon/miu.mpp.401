package prob1.partE.ii;

public interface A {
	void method();
	
}
