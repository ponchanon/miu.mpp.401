package prob1.partE.ii;

public interface B extends A{
	  void method();
}
