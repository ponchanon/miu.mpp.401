package prob3b;

public class Main {
	public static void main(String[] args) {
		Circle circle = new Circle(5);
		circle.computeArea();
		
		System.out.println(circle.computeArea());
	}
}
