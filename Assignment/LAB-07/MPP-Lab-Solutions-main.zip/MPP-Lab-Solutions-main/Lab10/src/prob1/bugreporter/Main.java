package prob1.bugreporter;

import java.util.stream.Stream;

import prob5.Employee;

public class Main {

	public static void main(String[] args) {
		BugReportGenerator brg = new BugReportGenerator();
		brg.reportGenerator();

	}

}
