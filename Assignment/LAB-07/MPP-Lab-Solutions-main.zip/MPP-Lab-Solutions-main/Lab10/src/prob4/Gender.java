package prob4;

public enum Gender {
	M, F
}
