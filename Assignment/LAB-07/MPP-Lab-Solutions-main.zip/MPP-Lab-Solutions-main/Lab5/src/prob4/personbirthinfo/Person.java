package prob4.personbirthinfo;

public class Person {
	private String name;
	private BirthInfo birthInfo;
	Person(String name) {
		this.name = name;
	}
}
