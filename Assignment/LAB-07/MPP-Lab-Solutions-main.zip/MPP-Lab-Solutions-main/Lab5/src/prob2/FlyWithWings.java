package prob2;

public class FlyWithWings implements FlyBehaviour {

	@Override
	public void fly() {
		// TODO Auto-generated method stub
		System.out.println("	fly with wings");
		
	}

}
