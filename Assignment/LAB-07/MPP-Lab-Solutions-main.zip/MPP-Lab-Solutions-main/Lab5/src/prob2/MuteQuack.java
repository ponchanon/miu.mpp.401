package prob2;

public class MuteQuack  implements QuackBehaviour{

	@Override
	public void quack() {
		// TODO Auto-generated method stub
		System.out.println("	cannot quack");
	}

}
