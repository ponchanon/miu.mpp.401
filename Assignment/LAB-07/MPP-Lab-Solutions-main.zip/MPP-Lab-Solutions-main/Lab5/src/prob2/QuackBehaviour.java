package prob2;

public interface QuackBehaviour {
	public void quack();
}
