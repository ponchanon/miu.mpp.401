package prob2;

public class CannotFly implements FlyBehaviour{

	@Override
	public void fly() {
		// TODO Auto-generated method stub
		System.out.println("	cannot fly");
	}

}
