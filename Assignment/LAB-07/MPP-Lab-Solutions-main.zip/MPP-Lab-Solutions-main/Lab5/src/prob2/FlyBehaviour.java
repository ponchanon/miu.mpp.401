package prob2;

public interface FlyBehaviour {
  public void fly();
}
