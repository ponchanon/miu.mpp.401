package prob3;

public interface ClosedCurve {
	public double computeArea();
}
