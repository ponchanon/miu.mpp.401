package prob2;

public class CheckoutRecordEntry {
	
}
