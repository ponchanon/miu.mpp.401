package lesson10.exercise_2_soln;

@BugReport
public class MoreBadCode {
	public int subtract(int a, int b) {
		return a + b;
	}
}
