package lesson10.exercise_2_soln;

@BugReport(assignedTo = "Levi", severity = 2)
public class StillMoreBadCode {

	public int multiply(int x, int y) {
		return x / y;

	}

}
