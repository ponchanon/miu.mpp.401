package lesson5.exercise_2_soln;

public interface Iface2 {
	int myMethod(int x);
}
