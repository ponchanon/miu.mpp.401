package lesson7.exercise_4_soln.prob3;

public class Impl implements Iface1, Iface2 {
	
}
