package lesson4.lecture.openclosed.closedcurve.good;

abstract public class ClosedCurve {
	abstract double computeArea();

}
