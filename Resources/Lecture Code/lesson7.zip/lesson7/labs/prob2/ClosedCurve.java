package lesson7.labs.prob2;

public interface ClosedCurve {	
	double computePerimeter();
}
