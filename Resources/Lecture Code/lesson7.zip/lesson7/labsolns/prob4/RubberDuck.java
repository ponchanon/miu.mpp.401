package lesson7.labsolns.prob4;

public class RubberDuck extends Duck implements Unquackable {
	
	@Override
	public void display() {
		System.out.println("  displaying");
		
	}
}
