package lesson7.labsolns.prob4;

public class RedheadDuck extends Duck implements Quackable, Flyable {
	
	@Override
	public void display() {
		System.out.println("  displaying");
		
	}
}
