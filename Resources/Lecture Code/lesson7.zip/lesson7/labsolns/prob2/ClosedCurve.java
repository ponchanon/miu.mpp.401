package lesson7.labsolns.prob2;

public interface ClosedCurve {
	public double computePerimeter();
}
