package lesson7.lecture.interfacestatic;

public class Util {
	public static String formatDouble(double x) {
		return String.format("%.2f", x);
	}
}
