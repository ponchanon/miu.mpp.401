package lesson7.lecture.defaultmethodrules.inherit;

public class SubImpl implements SubIntface {
	
}
