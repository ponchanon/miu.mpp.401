package lesson7.lecture.enums2;

public enum Dim {

}
