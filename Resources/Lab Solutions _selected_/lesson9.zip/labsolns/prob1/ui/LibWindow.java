package lesson9.labsolns.prob1.ui;

public interface LibWindow {
	void init();
	boolean isInitialized();
	void isInitialized(boolean val);
}
