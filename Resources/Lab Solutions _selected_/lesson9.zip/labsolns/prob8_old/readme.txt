This version uses flatMap but requires
modification of getters so that they
return Optionals.

New version uses map instead.