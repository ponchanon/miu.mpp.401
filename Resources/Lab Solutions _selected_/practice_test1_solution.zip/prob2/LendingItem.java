package prob2;

public class LendingItem {
	private int numCopiesInLib;
	public void setNumCopiesInLib(int numCopiesInLib) {
		this.numCopiesInLib = numCopiesInLib;
	}
	public int getNumCopiesInLib() {
		return numCopiesInLib;
	}
}
