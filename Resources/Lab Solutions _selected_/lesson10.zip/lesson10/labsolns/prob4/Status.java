package lesson10.labsolns.prob4;

public enum Status {
	GOLD, SILVER, COMMON, ILLEGAL
}
