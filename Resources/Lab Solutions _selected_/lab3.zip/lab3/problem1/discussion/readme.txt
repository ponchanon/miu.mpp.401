The reason there are different results when
testing for equality is this:

   