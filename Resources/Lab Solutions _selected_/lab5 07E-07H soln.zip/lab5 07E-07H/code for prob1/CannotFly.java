package lesson5.labsolns.prob2;

public class CannotFly implements FlyBehavior {
	public void fly() {
		System.out.println("  cannot fly");
	}
}
