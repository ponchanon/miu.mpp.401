package lesson5.labsolns.prob2;

public class Quack implements QuackBehavior {
	public void quack() {
		System.out.println("  quacking");
	}
}
